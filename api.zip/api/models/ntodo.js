/*'use strict'

const mongoose = require('mongoose'),
      mongooseApiQuery = require('mongoose-api-query'),
      createdModified = require('mongoose-createdmodified').createdModifiedPlugin

const NTodoSchema = new mongoose.Schema({
    task: {
        type: String,
        required: true,
        trim: true,
    },
    status: {
        type: String,
        required: true,
        enum: ['pending', 'complete', 'overdue']
    },
}, { minimize: false });

NTodoSchema.plugin(mongooseApiQuery)
NTodoSchema.plugin(createdModified, { index: true })

const NTodo = mongoose.model('NTodo', NTodoSchema)
module.exports = NTodo
*/